<template>
  <div>
    <div class="card d-flex flex-wrap" style="width: 18rem;">
      <img :src="image(movie.poster_path)" class="card-img-top" alt="#">
      <div class="card-body card-custom">
        <h4 class="card-title text-style">{{ movie.title }}</h4>
        <p class="card-text text-style">{{movie.overview}}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MovieCard',
  props: {
    movie: {
      type: Object,
      required: true,
    },
  },
  methods: {
    image(img) {
      return `https://image.tmdb.org/t/p/w300/${img}`
    }
  }
}
</script>

<style>
  .text-style {
    font-family: Cafe24Oneprettynight;
  }

  .card-custom {
    object-fit: cover;
  }
</style>